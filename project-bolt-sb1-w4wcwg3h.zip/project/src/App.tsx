import React from 'react';
import { 
  Phone, 
  MessageCircle, 
  Mail, 
  Star, 
  Users, 
  TrendingUp,
  Globe,
  Instagram,
  Linkedin,
  Search,
  Stethoscope,
  Heart,
  Award,
  Shield,
  Clock,
  CheckCircle,
  MapPin,
  Calendar,
  ArrowRight,
  Play
} from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm fixed w-full top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Stethoscope className="h-8 w-8 text-[#b23330]" />
              <span className="ml-2 text-xl font-bold text-gray-900">MedGrow</span>
            </div>
            <div className="hidden md:flex items-center space-x-6">
              <a href="#services" className="text-gray-600 hover:text-[#b23330] transition-colors">Services</a>
              <a href="#results" className="text-gray-600 hover:text-[#b23330] transition-colors">Results</a>
              <a href="#testimonials" className="text-gray-600 hover:text-[#b23330] transition-colors">Testimonials</a>
              <div className="flex items-center space-x-4">
                <a href="tel:+919876543210" className="text-[#b23330] hover:text-red-800">
                  <Phone className="h-5 w-5" />
                </a>
                <a href="https://wa.me/919876543210" className="text-green-600 hover:text-green-700">
                  <MessageCircle className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-20 bg-gradient-to-br from-red-50 via-white to-red-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Get More Surgeries & Consultations With{' '}
              <span className="text-[#b23330]">15–30 New Patients</span>{' '}
              Monthly
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-4xl mx-auto">
              Increase Your Online Reputation & Patient Bookings Through Google, Instagram, Website & LinkedIn — 
              Fill Your Calendar With Quality Patients.
            </p>
            <button className="bg-[#b23330] hover:bg-red-800 text-white font-semibold py-4 px-8 rounded-lg text-lg transition-colors inline-flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Get More Patients - Free 15-Min Call
            </button>
            <div className="mt-8 flex justify-center items-center space-x-8 text-sm text-gray-500">
              <div className="flex items-center">
                <Users className="h-4 w-4 mr-1" />
                25+ Doctors Served
              </div>
              <div className="flex items-center">
                <TrendingUp className="h-4 w-4 mr-1" />
                More Surgeries & Consultations
              </div>
              <div className="flex items-center">
                <Shield className="h-4 w-4 mr-1" />
                Better Online Reputation
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Are These Problems Costing You Patients?
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-red-100">
              <div className="text-red-500 mb-3">
                <Search className="h-8 w-8" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Empty consultation slots?</h3>
              <p className="text-gray-600 text-sm">Patients can't find you online when they need your specialty services.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-red-100">
              <div className="text-red-500 mb-3">
                <TrendingUp className="h-8 w-8" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Competitors getting more surgeries?</h3>
              <p className="text-gray-600 text-sm">Other doctors appear first online and book all the high-value procedures.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-red-100">
              <div className="text-red-500 mb-3">
                <Star className="h-8 w-8" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Poor online reputation?</h3>
              <p className="text-gray-600 text-sm">Few reviews and weak online presence make patients choose other doctors.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-red-100">
              <div className="text-red-500 mb-3">
                <Calendar className="h-8 w-8" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Low appointment bookings?</h3>
              <p className="text-gray-600 text-sm">Your calendar isn't full because patients don't trust your online presence.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Dream Outcome Section */}
      <section className="py-20 bg-gradient-to-r from-red-50 to-red-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Imagine Your Practice Like This...
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <div className="text-[#b23330] mb-4">
                  <Calendar className="h-12 w-12 mx-auto" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Fully Booked Calendar</h3>
                <p className="text-gray-600">Your consultation slots and surgery schedule stay consistently full with quality patients.</p>
              </div>
            </div>
            <div className="text-center">
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <div className="text-[#b23330] mb-4">
                  <Star className="h-12 w-12 mx-auto" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">5-Star Online Reputation</h3>
                <p className="text-gray-600">Patients see excellent reviews and trust you before they even visit your clinic.</p>
              </div>
            </div>
            <div className="text-center">
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <div className="text-[#b23330] mb-4">
                  <TrendingUp className="h-12 w-12 mx-auto" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Higher Revenue Per Month</h3>
                <p className="text-gray-600">More consultations and surgeries mean significantly increased monthly practice income.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What We Do For You
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Complete done-for-you system that fills your calendar with 15-30 quality patients monthly
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-8 rounded-lg hover:shadow-lg transition-shadow">
              <div className="text-[#b23330] mb-4">
                <Search className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Google My Business Management</h3>
              <p className="text-gray-600">Dominate local search results so patients book consultations with you, not competitors.</p>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg hover:shadow-lg transition-shadow">
              <div className="text-[#b23330] mb-4">
                <Instagram className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Instagram Strategy & Reels</h3>
              <p className="text-gray-600">Build massive trust and credibility that converts followers into high-value patients.</p>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg hover:shadow-lg transition-shadow">
              <div className="text-[#b23330] mb-4">
                <Globe className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Website Redesign & SEO</h3>
              <p className="text-gray-600">Professional website that instantly builds trust and converts visitors into booked surgeries.</p>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg hover:shadow-lg transition-shadow">
              <div className="text-[#b23330] mb-4">
                <Star className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Reputation Management</h3>
              <p className="text-gray-600">Build 5-star reputation across all platforms so patients choose you over competitors.</p>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg hover:shadow-lg transition-shadow">
              <div className="text-[#b23330] mb-4">
                <Linkedin className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">LinkedIn Professional Positioning</h3>
              <p className="text-gray-600">Position yourself as the go-to specialist and attract premium patients and referrals.</p>
            </div>
            <div className="bg-gradient-to-br from-red-50 to-red-100 p-8 rounded-lg border-2 border-[#b23330]">
              <div className="text-[#b23330] mb-4">
                <TrendingUp className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Complete Growth System</h3>
              <p className="text-gray-600">Everything working together to maximize consultations, surgeries, and monthly revenue.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section id="results" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Real Results: More Surgeries & Revenue
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white p-8 rounded-lg shadow-sm text-center">
              <div className="text-4xl font-bold text-[#b23330] mb-2">25+</div>
              <div className="text-gray-600">Specialists Helped</div>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-sm text-center">
              <div className="text-4xl font-bold text-[#b23330] mb-2">40%</div>
              <div className="text-gray-600">More Surgeries In 60 Days</div>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-sm text-center">
              <div className="text-4xl font-bold text-[#b23330] mb-2">15-30</div>
              <div className="text-gray-600">Quality Patients Monthly</div>
            </div>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <Calendar className="h-8 w-8 text-[#b23330] mx-auto mb-3" />
              <h4 className="font-semibold text-gray-900 mb-2">Full Calendars</h4>
              <p className="text-sm text-gray-600">Consistent consultation bookings</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <TrendingUp className="h-8 w-8 text-[#b23330] mx-auto mb-3" />
              <h4 className="font-semibold text-gray-900 mb-2">Higher Revenue</h4>
              <p className="text-sm text-gray-600">Increased monthly practice income</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <Star className="h-8 w-8 text-yellow-500 mx-auto mb-3" />
              <h4 className="font-semibold text-gray-900 mb-2">5-Star Reviews</h4>
              <p className="text-sm text-gray-600">Strong online reputation</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <Shield className="h-8 w-8 text-[#b23330] mx-auto mb-3" />
              <h4 className="font-semibold text-gray-900 mb-2">Quality Patients</h4>
              <p className="text-sm text-gray-600">Serious patients, not time-wasters</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Real Doctors, Real Results
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <Stethoscope className="h-6 w-6 text-[#b23330]" />
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-900">Dr. Priya Sharma</h4>
                  <p className="text-sm text-gray-600">Cardiologist, Mumbai</p>
                </div>
              </div>
              <div className="flex mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-600">"My surgery bookings increased by 60% in just 2 months. Now I have a waiting list for consultations and my practice revenue has doubled."</p>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <Heart className="h-6 w-6 text-[#b23330]" />
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-900">Dr. Rajesh Patel</h4>
                  <p className="text-sm text-gray-600">Orthopedic Surgeon, Delhi</p>
                </div>
              </div>
              <div className="flex mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-600">"From 2-3 surgeries per week to 8-10. My online reputation is now so strong that patients specifically request me over other orthopedic surgeons."</p>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <Award className="h-6 w-6 text-[#b23330]" />
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-900">Dr. Anita Desai</h4>
                  <p className="text-sm text-gray-600">Dermatologist, Bangalore</p>
                </div>
              </div>
              <div className="flex mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-600">"My consultation fees increased by 50% because of my improved reputation. Patients now see me as the premium choice for dermatology treatments."</p>
            </div>
          </div>
        </div>
      </section>

      {/* Strong CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#b23330] to-red-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready To Fill Your Calendar With Quality Patients?
          </h2>
          <p className="text-xl text-red-100 mb-8 max-w-3xl mx-auto">
            See exactly how many more surgeries and consultations you could get in the next 30 days
          </p>
          <button className="bg-white text-[#b23330] hover:bg-gray-100 font-semibold py-4 px-8 rounded-lg text-lg transition-colors inline-flex items-center">
            <Calendar className="h-5 w-5 mr-2" />
            Get More Patients - Free 15-Min Call
            <ArrowRight className="h-5 w-5 ml-2" />
          </button>
          <p className="text-red-100 mt-4 text-sm">No obligation • Free consultation • See your revenue potential</p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Start Getting More Patients Today
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Ready To Grow Your Practice?</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-[#b23330] mr-3" />
                  <span className="text-gray-600">+91 98765 43210</span>
                </div>
                <div className="flex items-center">
                  <MessageCircle className="h-5 w-5 text-green-600 mr-3" />
                  <span className="text-gray-600">WhatsApp: +91 98765 43210</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-[#b23330] mr-3" />
                  <span className="text-gray-600">hello@medgrow.in</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Get Your Growth Plan</h3>
              <form className="space-y-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#b23330] focus:border-transparent"
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#b23330] focus:border-transparent"
                />
                <input
                  type="tel"
                  placeholder="Your Phone"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#b23330] focus:border-transparent"
                />
                <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#b23330] focus:border-transparent">
                  <option>Select Your Specialty</option>
                  <option>Cardiology</option>
                  <option>Dermatology</option>
                  <option>Orthopedics</option>
                  <option>Pediatrics</option>
                  <option>Other</option>
                </select>
                <button
                  type="submit"
                  className="w-full bg-[#b23330] hover:bg-red-800 text-white font-semibold py-3 rounded-lg transition-colors"
                >
                  Get My Growth Plan
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Stethoscope className="h-8 w-8 text-[#b23330]" />
                <span className="ml-2 text-xl font-bold">MedGrow</span>
              </div>
              <p className="text-gray-400">
                Helping specialist doctors get more surgeries, consultations, and build stronger online reputations through proven digital marketing.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Google My Business</li>
                <li>Instagram Marketing</li>
                <li>Website Development</li>
                <li>Directory Listings</li>
                <li>LinkedIn Optimization</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-gray-400">
                <li>+91 98765 43210</li>
                <li>hello@medgrow.in</li>
                <li>WhatsApp Support</li>
                <li>24/7 Available</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Results</h3>
              <ul className="space-y-2 text-gray-400">
                <li>✓ More Surgeries Monthly</li>
                <li>✓ Full Consultation Calendar</li>
                <li>✓ 5-Star Online Reputation</li>
                <li>✓ Higher Practice Revenue</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 MedGrow. All rights reserved. Helping doctors get more surgeries, consultations, and build stronger reputations.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;